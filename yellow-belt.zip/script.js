function changeimage (elemnt){
    elemnt.src = "succulents-2.jpg";
}
function changeimageback(element){
    element.src ="succulents-1.jpg"
}
function Cookie() {
    cookieBox.remove();
}

var cookieBox = document.querySelector(".cookie-policy");